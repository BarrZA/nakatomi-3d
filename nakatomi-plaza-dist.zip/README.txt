Nakatomi Plaza – Dist
=====================

This folder serves the scene with a tiny local server so modern browsers can load ES modules.

Quick start (Mac):
1) Double-click `start-mac.command` (you may need to approve it in Security & Privacy).
2) Your browser will open http://localhost:5500/dist .

Quick start (Windows):
1) Double-click `start-windows.bat`.
2) Your browser will open http://localhost:5500/dist .

If you prefer the manual route:
- Open Terminal/Command Prompt in the parent folder of `dist/` and run:
  python3 -m http.server 5500
- Then browse to http://localhost:5500/dist
